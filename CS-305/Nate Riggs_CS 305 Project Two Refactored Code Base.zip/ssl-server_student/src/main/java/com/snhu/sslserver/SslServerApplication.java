package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import org.apache.commons.codec.binary.Hex;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController {

    /**
     * Calculates the SHA-256 hash of the provided data string.
     *
     * @param data The input string to be hashed.
     * @return The hexadecimal representation of the hash.
     * @throws RuntimeException if the SHA-256 algorithm is not available.
     */
    public static String calculateHash(String data) {
    	try {
            // Create a MessageDigest instance for SHA-256
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            // Convert the input  data to a byte array using UTF-8 encoding
            byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);

            // Generate the hash bytes from the input data
            byte[] hashBytes = digest.digest(dataBytes);

            // Convert the hash bytes to a hexadecimal string
            String hexString = Hex.encodeHexString(hashBytes);

            return hexString; // Return the complete hex string
        } catch (NoSuchAlgorithmException e) {
            // Throw runtime exception if SHA-256 is unavailable
            throw new RuntimeException("Error generating SHA-256 hash", e);
        }
    }
    /**
     * REST endpoint that returns the SHA-256 hash of a predefined data string.
     *
     * @return A formatted string containing the data and its hash.
     */
    @RequestMapping("/hash")
    public String myHash() {
        // Define the data string to be hashed
        String data = "Hello Nate Riggs! This is the Check Sum for Artemis Financial";
        
        // Calculate the hash of the data
        String hash = calculateHash(data);
        
        // Return the data and its hash as an HTML formatted string
        return "<p>Data: " + data + " : Selected Cipher = SHA-256: " + hash + "</p>";
    }
}
