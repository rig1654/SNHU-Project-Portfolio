// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <stdexcept>    // std::overflow_error, std::underflow_error

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // CHANGE: Added overflow and underflow detection
        // Check before performing addition to prevent overflow/underflow
        // Formulas are rearranged to avoid overflow during the check itself

        if (increment > 0)
        {
            // Positive increment: check for overflow
            // Original check: result + increment > max
            // Rearranged to: result > max - increment (avoids overflow in the comparison)
            if (result > std::numeric_limits<T>::max() - increment)
            {
                // Throw exception to notify caller that overflow would occur
                throw std::overflow_error("Overflow detected in add_numbers");
            }
        }
        else if (increment < 0)
        {
            // Negative increment: check for underflow
            // Original check: result + increment < min
            // Rearranged to: result < min - increment (avoids underflow in the comparison)
            if (result < std::numeric_limits<T>::min() - increment)
            {
                // Throw exception to notify caller that underflow would occur
                throw std::underflow_error("Underflow detected in add_numbers");
            }
        }
        // If increment is zero, no overflow or underflow is possible

        result += increment;
    }

    return result;
}


/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // CHANGE: Added underflow and overflow detection
        // Check before performing subtraction to prevent underflow/overflow
        // Formulas are rearranged to avoid underflow during the check itself

        if (decrement > 0)
        {
            // Positive decrement: check for underflow
            // Original check: result - decrement < min
            // Rearranged to: result < min + decrement (avoids underflow in the comparison)
            if (result < std::numeric_limits<T>::min() + decrement)
            {
                // Throw exception to notify caller that underflow would occur
                throw std::underflow_error("Underflow detected in subtract_numbers");
            }
        }
        else if (decrement < 0)
        {
            // Negative decrement: subtracting a negative is addition, check for overflow
            // Original check: result - (-value) = result + value > max
            // Rearranged to: result > max + decrement (where decrement is negative)
            if (result > std::numeric_limits<T>::max() + decrement)
            {
                // Throw exception to notify caller that overflow would occur
                throw std::overflow_error("Overflow detected in subtract_numbers");
            }
        }
        // If decrement is zero, no overflow or underflow is possible

        result -= decrement;
    }

    return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";

    // CHANGE: Added try-catch block to handle overflow exceptions
    // This allows the function to detect when add_numbers throws an exception
    try
    {
        // Call add_numbers - may throw exception if overflow detected
        T result = add_numbers<T>(start, increment, steps + 1);

        // CHANGE: If no exception thrown, display result with overflow status false
        std::cout << +result << " (Overflow: false)" << std::endl;
    }
    catch (const std::overflow_error&)
    {
        // CHANGE: Overflow exception caught - notify user overflow occurred
        std::cout << "error (Overflow: true)" << std::endl;
    }
    catch (const std::underflow_error&)
    {
        // CHANGE: Underflow exception caught (can occur with negative increments)
        std::cout << "error (Overflow: true)" << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";

    // CHANGE: Added try-catch block to handle underflow exceptions
    // This allows the function to detect when subtract_numbers throws an exception
    try
    {
        // Call subtract_numbers - may throw exception if underflow detected
        T result = subtract_numbers<T>(start, decrement, steps + 1);

        // CHANGE: If no exception thrown, display result with underflow status false
        std::cout << +result << " (Underflow: false)" << std::endl;
    }
    catch (const std::underflow_error&)
    {
        // CHANGE: Underflow exception caught - notify user underflow occurred
        std::cout << "error (Underflow: true)" << std::endl;
    }
    catch (const std::overflow_error&)
    {
        // CHANGE: Overflow exception caught (can occur with negative decrements)
        std::cout << "error (Underflow: true)" << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu