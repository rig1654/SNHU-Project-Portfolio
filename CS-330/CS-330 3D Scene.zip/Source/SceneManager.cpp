///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// FINAL UPDATE: Added additional objects with textures and material definitions in order to complete the image
//				 Positioned objects in scene relative to where they were in the original image and created lighting artifacts to have a similar look to the original scene
// 
// AUTHOR: Nate Riggs
// DATE: 02/20/2025
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;

	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/

void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL graniteMaterial;
	graniteMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f); // Slightly brighter ambient to compensate for diffuse lighting
	graniteMaterial.ambientStrength = 0.6f; // Increased ambient strength for the diffuse lighting
	graniteMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f); // Light gray, close to the observed color
	graniteMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f); // Very low specular for a non-reflective surface
	graniteMaterial.shininess = 2.0; // Very low shininess for a matte appearance
	graniteMaterial.tag = "granite";

	m_objectMaterials.push_back(graniteMaterial);

	OBJECT_MATERIAL grassMaterial;
	grassMaterial.ambientColor = glm::vec3(0.2f, 0.5f, 0.2f); // Green tint with moderate brightness
	grassMaterial.ambientStrength = 0.7f; // Slightly higher ambient to simulate light scattering in grass
	grassMaterial.diffuseColor = glm::vec3(0.3f, 0.6f, 0.3f); // Soft green with a natural look
	grassMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f); // Low specular for a matte surface
	grassMaterial.shininess = 5.0f; // Low shininess to prevent excessive reflections
	grassMaterial.tag = "grass";

	m_objectMaterials.push_back(grassMaterial);

	OBJECT_MATERIAL gravelMaterial;
	gravelMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f); // Neutral gray with slight darkness
	gravelMaterial.ambientStrength = 0.5f; // Standard ambient to maintain natural lighting
	gravelMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f); // Light gray to mimic small stone reflections
	gravelMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f); // Some specular to represent tiny rock reflections
	gravelMaterial.shininess = 10.0f; // Slightly higher than grass to reflect small stone grains
	gravelMaterial.tag = "gravel";

	m_objectMaterials.push_back(gravelMaterial);

	OBJECT_MATERIAL cementBrickMaterial;
	cementBrickMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f); // Neutral gray, slightly dark
	cementBrickMaterial.ambientStrength = 0.6f; // Moderate ambient to maintain a realistic look
	cementBrickMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f); // Standard gray cement tone
	cementBrickMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f); // Low specular for a rough, matte surface
	cementBrickMaterial.shininess = 5.0f; // Low shininess to reflect the rough texture of bricks
	cementBrickMaterial.tag = "cement_brick";

	m_objectMaterials.push_back(cementBrickMaterial);

	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.3f, 0.2f, 0.1f); // Warm brown tones for natural wood
	woodMaterial.ambientStrength = 0.5f; // Moderate ambient to capture wood's natural depth
	woodMaterial.diffuseColor = glm::vec3(0.5f, 0.3f, 0.2f); // Soft brown with a slightly richer midtone
	woodMaterial.specularColor = glm::vec3(0.05f, 0.03f, 0.02f); // Very low specular for a matte look
	woodMaterial.shininess = 3.0f; // Low shininess to avoid gloss and keep the texture natural
	woodMaterial.tag = "wood";

	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL roofTileMaterial;
	roofTileMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f); // Dark gray to match ceramic roof tiles
	roofTileMaterial.ambientStrength = 0.4f; // Lower ambient to prevent over-brightening
	roofTileMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f); // Standard dark ceramic color
	roofTileMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f); // Moderate specular for slight ceramic sheen
	roofTileMaterial.shininess = 15.0f; // Higher shininess to reflect some smooth ceramic properties
	roofTileMaterial.tag = "roof_tile";

	m_objectMaterials.push_back(roofTileMaterial);

}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/

void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Light 0: Main Light
	m_pShaderManager->setVec3Value("lightSources[0].position", 1.0f, 1.0f, 0.5f); // Positioned slightly above and in front
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.05f, 0.05f, 0.05f); // Low ambient light to avoid overexposure
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.22f, 0.22f, 0.18f); // Softened intensity
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.05f, 0.05f, 0.05f); // Subtle highlights
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 16.0f); // Controls the spread of light
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.09f); // Reduced specular reflections

	// Light 1: Fill Light
	m_pShaderManager->setVec3Value("lightSources[1].position", -0.7f, 0.8f, -0.2f); // Positioned to reduce shadows from the key light
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.06f, 0.06f, 0.06f); // Adds slight ambient brightness
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.45f, 0.45f, 0.4f); // Warmer tone to complement the key light
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.06f, 0.06f, 0.06f); // Mild specular effect
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f); // Softer spread compared to the key light
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.12f); // Moderate highlight intensity

	// Light 2: Overhead Light
	m_pShaderManager->setVec3Value("lightSources[2].position", 0.0f, 1.0f, 0.0f); // Positioned directly above
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.07f, 0.07f, 0.07f); // Soft ambient fill
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.35f, 0.35f, 0.3f); // Gentle illumination without overpowering the scene
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.08f, 0.08f, 0.08f); // Slightly sharper highlights than the fill light
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 64.0f); // Wider spread for even coverage
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.18f); // Stronger highlights

	// Light 3: Rim Light
	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, -0.5f, -1.0f); // Placed behind to outline the subject
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.05f, 0.05f, 0.05f); // Low ambient to prevent over-lighting
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.25f, 0.25f, 0.2f); // Subtle backlight for separation
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.05f, 0.05f, 0.05f); // Minimal specular to avoid glare
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 16.0f); // Focused backlight
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.08f); // Soft highlight to enhance depth




}

void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	bool bReturn = false;

	bReturn = CreateGLTexture("../../Utilities/textures/Gravel.jpg",
		"gravel");

	bReturn = CreateGLTexture("../../Utilities/textures/granite.jpg",
		"stone");
	bReturn = CreateGLTexture("../../Utilities/textures/grass.jpg",
		"grass");
	bReturn = CreateGLTexture("../../Utilities/textures/grey_wall2.jpg",
		"wall");
	bReturn = CreateGLTexture("../../Utilities/textures/wood-texture-floor-pattern-line-brown-1026418-pxhere.com.jpg",
		"wood_foundation");
	bReturn = CreateGLTexture("../../Utilities/textures/rusticwood.jpg",
		"wood");

	bReturn = CreateGLTexture("../../Utilities/textures/dark_granite.jpg",
		"dark_granite");

	bReturn = CreateGLTexture("../../Utilities/textures/ROCK.jpg", "rock");

	bReturn = CreateGLTexture("../../Utilities/textures/wood slat.jpg", "slat");

	bReturn = CreateGLTexture("../../Utilities/textures/rusticwood.jpg", "rustic_wood");

	bReturn = CreateGLTexture("../../Utilities/textures/roof.jpg", "roof");




	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	// load the texture image files for the textures applied
	// to objects in the 3D scene
	LoadSceneTextures();
	// define the materials that will be used for the objects
	// in the 3D scene
	DefineObjectMaterials();

	// add and define the light sources for the 3D scene
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadTaperedCylinderMesh(); //Load tapered cylinder for use on stone lantern
	m_basicMeshes->LoadBoxMesh(); // Load Box for use on Stone Lanter
	m_basicMeshes->LoadSphereMesh(); //Load Sphere to use to draw Half Sphere for Stone Lantern
	m_basicMeshes->LoadCylinderMesh(); // Load cylinder to use for various purposes like supports for house
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadTorusMesh();
}

/***********************************************************
 *  RenderGrass()
 *
 *  This method is used for rendering the plane to be used as grass
 ***********************************************************/

void SceneManager::RenderGrass()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	// Plane for ground
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(25.0f, 5.0f, 20.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.654, 0.592, 0.118, 1);
	SetShaderTexture("grass");
	SetTextureUVScale(5.0, 5.0);
	SetShaderMaterial("grass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

}

/***********************************************************
 *  RenderLantern()
 *
 *  This method is used for rendering the multiple 3D objects that make up
 *  the stone lantern
 ***********************************************************/
void SceneManager::RenderLantern()
{

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;


	//Base of lantern
		// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.0f, 2.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-5.0f, 1.0f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.514, 0.514, 0.516, 1);
	SetShaderTexture("dark_granite");
	SetTextureUVScale(1, 1);
	SetShaderMaterial("granite");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// Tapered section of lantern on top of base
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.75f, 0.75f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-5.0f, 2.8f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("dark_granite");
	SetTextureUVScale(1, 1);
	SetShaderMaterial("granite");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();
	/****************************************************************/
	// Tapered cylinder to use as lid for lantern under sphere
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 2.0f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-5.0f, 3.75f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("stone");
	SetTextureUVScale(1, 1);
	SetShaderMaterial("granite");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.75f, 1.25f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-5.0f, 4.5f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("dark_granite");
	SetTextureUVScale(1, 1);
	SetShaderMaterial("granite");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();

	/****************************************************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 0.5f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-5.0f, 5.85f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("dark_granite");
	SetTextureUVScale(1, 1);
	SetShaderMaterial("granite");

	m_basicMeshes->DrawTorusMesh();

	//Decorative sphere on top of lantern
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(-0.5f, 0.75f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-5.0f, 5.85f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("stone");
	SetTextureUVScale(0.5, 0.5);
	SetShaderMaterial("granite");

	// draw the mesh with transformation values
	m_basicMeshes->DrawHalfSphereMesh();
}

/***********************************************************
 *  RenderPath()
 *
 *  This method is used for rendering plane that will make up the gravel path
 ***********************************************************/
void SceneManager::RenderPath()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;


	// Plane for gravel path
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 1.5f, 20.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 15.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.1f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.8, 0.8, 0.8, 1);

	SetShaderTexture("gravel");
	SetTextureUVScale(5, 5);
	SetShaderMaterial("gravel");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderRock()
 *
 *  This method is used for rendering the rock in front of the stone lantern
 ***********************************************************/

void SceneManager::RenderRock()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.0f, 7.0f, 3.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-7.0f, 0.0f, 5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("rock");
	SetTextureUVScale(.5, .5);
	SetShaderMaterial("granite");


	m_basicMeshes->DrawHalfSphereMesh();

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 6.0f, 3.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-7.5f, 0.0f, -8.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("rock");
	SetTextureUVScale(1, 1);
	SetShaderMaterial("granite");

	m_basicMeshes->DrawHalfSphereMesh();
}

/***********************************************************
 *  RenderWall()
 *
 *  This method is used for rendering block wall in the back of the image
 ***********************************************************/

void SceneManager::RenderWall()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Box for brick wall
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(8.0f, 2.0f, 50.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 4.0f, -15.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("wall");
	SetTextureUVScale(5, 5);
	SetShaderMaterial("cement_brick");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

}

/***********************************************************
 *  RenderHouse()
 *
 *  This method is used for rendering the multiple 3D objects that will make up the house
 ***********************************************************/

void SceneManager::RenderHouse()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Box for foundation under house
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.5f, 17.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 195.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(13.0f, 0.75f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("wood_foundation");
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(10.0f, 1.5f, 13.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 195.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(13.0f, 2.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("slat");
	SetTextureUVScale(10, 10);

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(10.0f, 8.5f, 13.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 195.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(13.0f, 7.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("rustic_wood");
	SetTextureUVScale(0.1, 0.1);
	SetShaderMaterial("wood");
	

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// Wooden Pillar
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 10.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.5f, 1.0f, -5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("wood");
	SetTextureUVScale(0.1, 0.1);
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	// Wooden Pillar
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 10.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(18.0f, 1.0f, -9.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("wood");
	SetTextureUVScale(0.1, 0.1);
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	// Wooden Pillar
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 10.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(7.0f, 0.5f, 8.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("wood");
	SetTextureUVScale(0.1, 0.1);
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	// Box for foundation under house
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 4.0f, 17.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 195.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(13.0f, 12.5f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("roof");
	SetTextureUVScale(5, 5);
	SetShaderMaterial("roof_tile");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPyramid4Mesh();

	// Wooden Pillar
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 10.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(22.5f, 0.5f, 4.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("wood");
	SetTextureUVScale(0.1, 0.1);
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderGrass();
	RenderLantern();
	RenderPath();
	RenderWall();
	RenderHouse();
	RenderRock();
}
